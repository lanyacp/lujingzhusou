@echo off
setlocal
echo ж�� ·������ PowerPoint ��פ��...
reg delete "HKCU\Software\Microsoft\Office\16.0\PowerPoint\AddIns\ABPathHelper" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Office\16.0\PowerPoint\Trusted Locations\ABPathHelper" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Office\16.0\PowerPoint\Trusted Locations\Location88" /f >nul 2>&1
if exist "%APPDATA%\ABPathHelper" rmdir /s /q "%APPDATA%\ABPathHelper"
echo.
echo ж�����, ���� PowerPoint ��Ч.
pause